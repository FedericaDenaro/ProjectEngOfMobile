# Tandem app

Project for Engineering of mobile systmes. 

This application was developed using Expo Snack and Firebase as database, its aim is to reproduce the activity of tandem proposed by Unibz. The user once logged-in or signed-up can then search for a partner to do the tandem with by contacting him/her through email. The user is also able to see his/her profile and updating it.

# Main functionalities

 - Search by filtering with the language and the level that the user want
 - Going through profiles of the other User in order to choose the best on
 - Updating the profile with the language skills, photo profile and so on
 - Log out
 - Log in
 - Sign Up


Developed by Federica Denaro